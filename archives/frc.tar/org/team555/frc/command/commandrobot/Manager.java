package org.team555.frc.command.commandrobot;

public interface Manager 
{
    void always();
    void reset();
    void initialize();
}
