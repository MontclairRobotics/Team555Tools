package org.team555.function;

@FunctionalInterface
public interface DoublePredicate 
{
    boolean evaluate(double value);
}
